<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; <?php echo date('Y');?> Online Course Registration</a>
                </div>

            </div>
        </div>
    </footer>